const mockItems = [
    { id: 1, name: 'Item1', description: 'Description1', price: 9.99, quantity: 100 },
    { id: 2, name: 'Item2', description: 'Description2', price: 19.99, quantity: 200 },
];

module.exports = mockItems;
