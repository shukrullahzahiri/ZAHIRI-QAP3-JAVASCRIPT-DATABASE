const express = require('express');
const router = express.Router();
const dal = require('../dal/dal');

router.get('/', async (req, res) => {
    const items = await dal.getItems();
    res.render('index', { items });
});

router.get('/api/items', async (req, res) => {
    const items = await dal.getItems();
    res.json(items);
});

router.post('/api/items', async (req, res) => {
    const { name, description, price, quantity } = req.body;
    await dal.addItem(name, description, price, quantity);
    res.redirect('/');
});

router.put('/api/items/:id', async (req, res) => {
    const { id } = req.params;
    const { name, description, price, quantity } = req.body;
    await dal.updateItem(id, name, description, price, quantity);
    res.redirect('/');
});

router.delete('/api/items/:id', async (req, res) => {
    const { id } = req.params;
    await dal.deleteItem(id);
    res.redirect('/');
});

module.exports = router;
