SELECT * FROM items;

INSERT INTO items (name, description, price, quantity) VALUES ('Item1', 'Description1', 9.99, 100);

UPDATE items SET name = 'UpdatedItem', price = 19.99 WHERE id = 1;

DELETE FROM items WHERE id = 1;
