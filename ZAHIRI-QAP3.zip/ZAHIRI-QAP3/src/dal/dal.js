const { Pool } = require('pg');
const pool = new Pool({
    user: 'postgres',       // Your PostgreSQL username
    host: 'localhost',
    database: 'postgres',  // Your PostgreSQL database name
    password: 'Canada@123',   // Your PostgreSQL password
    port: 5432,
});

const getItems = async () => {
    const res = await pool.query('SELECT * FROM items');
    return res.rows;
};

const addItem = async (name, description, price, quantity) => {
    await pool.query('INSERT INTO items (name, description, price, quantity) VALUES ($1, $2, $3, $4)', [name, description, price, quantity]);
};

const updateItem = async (id, name, description, price, quantity) => {
    await pool.query('UPDATE items SET name = $1, description = $2, price = $3, quantity = $4 WHERE id = $5', [name, description, price, quantity, id]);
};

const deleteItem = async (id) => {
    await pool.query('DELETE FROM items WHERE id = $1', [id]);
};

module.exports = { getItems, addItem, updateItem, deleteItem };
